package com.example.demo.test;

import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.Tracker;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.TrackerRepo;

@SpringBootTest
public class TrackerTest {
	@Autowired
	TrackerRepo trackRepo;
	
	@Test
	public void insertTrackerTest() throws Exception{
		Tracker trackObj=new Tracker();
		//bankObj.setBankId(611);
		trackObj.setAprrovedDate(new SimpleDateFormat("dd/MM/yyyy").parse("12/12/2019"));
		trackObj.setStatus("Rejected");
		trackRepo.addTrackerDetails(trackObj);
        }
	
	
}
