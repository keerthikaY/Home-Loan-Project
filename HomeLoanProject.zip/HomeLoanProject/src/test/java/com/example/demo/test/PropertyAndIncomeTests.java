package com.example.demo.test;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer3.PropertyAndIncomeRepository;


@SpringBootTest
public class PropertyAndIncomeTests {
	
	@Autowired
	PropertyAndIncomeRepository propertyRepo;
	
	@Test
	public void  getPropertyByIdTest(){
		Propertyandincome propertyobj=propertyRepo.getPropertyAndIncomeListById(401);
		System.out.println("Application:"+propertyobj.getEmployerName());
		System.out.println("Application:"+propertyobj.getOrgType());
		System.out.println("Application:"+propertyobj.getPropertyLoc());
		System.out.println("Application:"+propertyobj.getPropertyName());

	}
	
	@Test
	public void insertPropertyAndIncomeTest() {
		Propertyandincome propertyObj=new Propertyandincome();
        propertyObj.setEmployerName("Realtor");
        propertyObj.setEstimatedAmt(200000L);
        propertyObj.setIncome(5000000L);
        propertyObj.setOrgType("Private");
        //propertyObj.setPropertyId(411);
        propertyObj.setPropertyLoc("Bangalore");//
        propertyObj.setPropertyName("Home");
        propertyObj.setRetAge(58);
        propertyObj.setTypeOfEmp("Employed");
        propertyObj.setApplication(null);
        propertyRepo.addPropertyAndIncomeDetails(propertyObj);
        }
	
	@Test
	public void updatePropertyAndIncomeTest() {
		Propertyandincome findObj=propertyRepo.getPropertyAndIncomeListById(404);
		System.out.println("Location: "+findObj.getPropertyLoc());
		findObj.setPropertyLoc("Chennai");
		propertyRepo.updatePropertyAndIncome(findObj);
		System.out.println("Location: "+findObj.getPropertyLoc());
	}
	
	@Test
	public void deletePropertyAndIncomeTest() {
		try {
		propertyRepo.deletePropertyAndIncome(404);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
				}
	}
	
	@Test
	public void getAllPropertyAndIncomeTest(){
		List<Propertyandincome> PropertyAndIncomeList=propertyRepo.getAllPropertyAndIncome();
		for(Propertyandincome property:PropertyAndIncomeList) {
			System.out.println("Property id: "+property.getPropertyId());
			System.out.println("Property location: "+property.getPropertyLoc());
			System.out.println("Property name: "+property.getPropertyName());
			System.out.println("Estimated amount: "+property.getEstimatedAmt());
			System.out.println("Type of Employee: "+property.getTypeOfEmp());
			System.out.println("Retirement Age: "+property.getRetAge());
			System.out.println("Organization type: "+property.getOrgType());
			System.out.println("Employer_name: "+property.getEmployerName());
			System.out.println("Income: "+property.getIncome());
		}
		
	}
}
