package com.example.demo.test;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.model.Bank;
import com.example.demo.layer3.ApplicationRepository;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.UserRegistrationRepo;

@SpringBootTest
public class UserTesting {
    
	@Autowired
	UserRegistrationRepo userRepo;
	@Autowired
	ApplicationRepository appRepo;
	
	@Test
	public void getUserByEmail() {
		System.out.println(userRepo.findUserByEmail("pranav@gmail.com"));
	
	}
	@Test
	public void getTrackerIdByUserID() {
		System.out.println(appRepo.getTrackerByAppId(101));
	
	}
	
}
