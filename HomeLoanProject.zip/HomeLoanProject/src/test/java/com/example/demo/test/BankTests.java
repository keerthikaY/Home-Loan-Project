package com.example.demo.test;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.PropertyAndIncomeRepository;
import com.example.demo.layer3.UserRegistrationRepo;


@SpringBootTest
public class BankTests {
	
	@Autowired
	BankRepository bankRepo;
	
	
	@Test
	public void  getBankByIdTest(){
		Bank bankObj=bankRepo.getBankById(601);
		System.out.println("Application:"+bankObj.getBankName());
		System.out.println("Application:"+bankObj.getAccNo());
		System.out.println("Application:"+bankObj.getIfscCode());
	}
	
	@Test
	public void insertBankTest() {
		Bank bankObj=new Bank();
		//bankObj.setBankId(611);
		bankObj.setAccNo(98756785763L);
		bankObj.setBankName("HDFC");
		bankObj.setIfscCode("HDFC9876");
        bankObj.setApplication(null);
        bankRepo.addBankDetails(bankObj);
        }
	
	@Test
	public void updateBankTest() {
		Bank findObj=bankRepo.getBankById(604);
		System.out.println("Location: "+findObj.getIfscCode());
		findObj.setIfscCode("HDFC8906");
		bankRepo.updateBankDetails(findObj);
		System.out.println("Location: "+findObj.getIfscCode());
	}
	
	@Test
	public void deleteBankTest() {
		try {
		bankRepo.deleteBankDetails(610);
		}
		catch(Exception e) {
			System.out.println(e.getMessage());
				}
	}
	//99      32242 jfbvkj               fcdc
	@Test
	public void getAllBankTest(){
		List<Bank> bankList=bankRepo.getAllBankDetails();
		for(Bank bank:bankList) {
			System.out.println("Acc No: "+bank.getAccNo());
			System.out.println("Bank Name: "+bank.getBankName());
			System.out.println("Bank IFSC code: "+bank.getIfscCode());
		}
		
	}
	@Test
	public void getApplicationByBank() {
		Application app=bankRepo.getApplicationByBankId(1234565436L);
		System.out.println(app.getAppId());
	}
	
	
}
