package com.example.demo.test;

import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.example.demo.layer2.model.Loan;
import com.example.demo.layer3.LoanRepository;

@SpringBootTest
public class LoanTest {
	
	@Autowired
	LoanRepository loanRepo;
	
	@Test
	public void getLoanDetailsByIdTest() {
		Loan loanobj=loanRepo.getLoanDetailsById(301);
		System.out.println("Tenure :"+loanobj.getTenure());
		System.out.println("Loan Amount:"+loanobj.getLoanAmount());
		System.out.println("Loan:"+loanobj.getRoi());
		System.out.println("Loan:"+loanobj.getEmi());
	}

	@Test
	public void addLoanDetailsTest() {
		Loan loanObj=new Loan();
		loanObj.setTenure(6);
		loanObj.setLoanAmount(700000L);
		loanObj.setRoi(3.8);
		loanObj.setEmi(35000.0);
		loanObj.setApplication(null);
		loanRepo.addLoanDetails(loanObj);
	}
	
	@Test
	public void updateLoanDetailsTest() {
		Loan findObj=loanRepo.getLoanDetailsById(303);
		System.out.println("Tenure : "+findObj.getTenure());
		findObj.setTenure(5);
		loanRepo.updateLoanDetails(findObj);
		System.out.println("Tenure : "+findObj.getTenure());
	}
	
	@Test
	public void deleteLoanDetailsTest() {
		loanRepo.deleteLoanDetails(81);
	}
	
	@Test
	public void getAllLoanDetailsTest(){
		List<Loan> LoanList=loanRepo.getAllLoanDetails();
		for(Loan loan:LoanList) {
			System.out.println("Loan id : "+loan.getLoanId());
			System.out.println("Tenure : "+loan.getTenure());
			System.out.println("Loan Amount : "+loan.getLoanAmount());
			System.out.println("Rate of Interest : "+loan.getRoi());
			System.out.println("EMI : "+loan.getEmi());
			System.out.println("=====================");
		}
		
	}
	
	@Test
	public void getLoanByAppId() {
		Loan l=loanRepo.getLoanByAppId(101);
		System.out.println(l.getTenure());
	}
}