package com.example.demo.test;

import java.util.List;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.Document;
import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer2.model.Tracker;
import com.example.demo.layer3.ApplicationRepository;
import com.example.demo.layer3.DocumentRepository;
import com.example.demo.layer3.PropertyAndIncomeRepository;

@SpringBootTest
class DocumentTest {
	

	@Autowired
	ApplicationRepository AppRepo;
	@Autowired
	PropertyAndIncomeRepository propertyRepo;
	@Autowired
	DocumentRepository docrepo;
		
	@Test
	public void  getApp(){
		Application appobj=AppRepo.getApplication(101);
		System.out.println("Application:"+appobj.getAppId());
		System.out.println("Application:"+appobj.getDateOfApp());
		System.out.println("Application:"+appobj.getHomeUser().getUserId());
		System.out.println("Application:"+appobj.getTracker().getTrackerId());

	}
	
	@Test
	void getAllApplicationsTest() {
//		ApplicationContext ctx = new ClassPathXmlApplicationContext("SpringConfig.xml");
//		deptRepo = (DeptRepository) ctx.getBean("deptRepo");
		List<Application> appobj = AppRepo.getAllApplications();
		for(Application d: appobj)
		{
			System.out.println("Application Number: "+d.getAppId());
			System.out.println("Application Date: "+d.getDateOfApp());
			System.out.println("Application UserID: "+d.getHomeUser().getUserId());
			System.out.println("Application UserID: "+d.getHomeUser().getFirstName());
			System.out.println("Application:"+d.getTracker().getTrackerId());
			System.out.println("Application docId:"+d.getDocument().getDocId());

			
			System.out.println("=============");
		}
	}
	@Test
	public void addApplicantDetailsTest()throws Exception
	{
		Application appToInsert=new Application();
		/*appobj.setDateOfApp(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2019"));
		appobj.setBank(null);
		appobj.setDocument(null);
		appobj.setHomeUser(null);
		appobj.setLoan(null);
		appobj.setPropertyandincome(null);
		appobj.setTracker(null);*/
		
		System.out.println("App Details added");
		appToInsert.setDateOfApp(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2019"));
		Bank bankObj=new Bank();
		bankObj.setAccNo(3224234L);
		bankObj.setBankName("jfbvkj");
		bankObj.setIfscCode("fcdc");
		appToInsert.setBank(bankObj);
		
		Document docObj=new Document();
		docObj.setAgreementToSale("fcrvcfv");
		docObj.setLoa("Vr");
		docObj.setNocFromBuilder("rvv");
		docObj.setPanCard("rvrv");
		docObj.setSalarySlip("rvr");
		docObj.setVoterId("cscse");
		appToInsert.setDocument(docObj);
		
		Propertyandincome propObj=new Propertyandincome();
		propObj.setEmployerName("cdrcdv");
		propObj.setEstimatedAmt(343454L);
		propObj.setIncome(2525454L);
		propObj.setOrgType("G gfvgf");
		propObj.setPropertyLoc("vf f");
		propObj.setPropertyName("vf  ");
		propObj.setRetAge(45);
		propObj.setTypeOfEmp("vfv");
		appToInsert.setPropertyandincome(propObj);
		
		Loan loanobj= new Loan();
		loanobj.setEmi(43445.0);
		loanobj.setLoanAmount(454547L);
		loanobj.setRoi(4.5);
		loanobj.setTenure(4);
		appToInsert.setLoan(loanobj);
		
		Tracker trackObj=new Tracker();
		//TrackObj.setAprrovedDate(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2019"));
		trackObj.setAprrovedDate(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2019"));
		trackObj.setStatus("gbgfbv");
		appToInsert.setTracker(trackObj);
		
		AppRepo.addApplicantDetails(appToInsert);
	}
	
	@Test
	 void updateApplicationDetailsTest()throws Exception
	 {
		Application findapp= AppRepo.getApplication(104);
		System.out.println("Doc Number: "+findapp.getAppId());
		System.out.println("Doc Voter ID: "+findapp.getDateOfApp());
		System.out.println("============After Updating=========");
		findapp.setDateOfApp(new SimpleDateFormat("dd/MM/yyyy").parse("01/12/2019"));
		AppRepo.updateApplication(findapp);
		System.out.println("Doc Number: "+findapp.getAppId());
		System.out.println("Doc Voter ID: "+findapp.getDateOfApp());

	 }
	
	@Test
	void deleteApplicationTestt() {
		try {
			AppRepo.deleteApplication(110);
			System.out.println("Object deleted..");
			}
			catch(Exception e) {
			System.out.println(e.getMessage());
			}
	}
	
	@Test
	public void addUserDocTest() {
		Document docobj = new Document();
	//	docobj.setDocId(211);
		docobj.setAgreementToSale("Agreementtosale.pdf");
		docobj.setLoa("loa.pdf");
		docobj.setNocFromBuilder("NOC.pdf");
		docobj.setPanCard("Pan_card.pdf");
		docobj.setSalarySlip("SalarySlip.pdf");
		docobj.setVoterId("VoterId.pdf");
		docobj.setApplication(null);
		docrepo.addUserDoc(docobj);

		System.out.println("document added");
	}
	
	@Test
	public  void getDocumentTest() {
		Document docobj=docrepo.getDocument(201);
		System.out.println("Document:"+docobj.getDocId());
		System.out.println("Document:"+docobj.getApplication().getAppId());
		System.out.println("Document:"+docobj.getPanCard());
		System.out.println("Document:"+docobj.getVoterId());

	}
	
	@Test
	 public void getAllUserDocumentsTest(){
		List<Document> doclist = docrepo.getAllUserDocuments();
		for(Document docobj: doclist)
		{
			System.out.println("Document:"+docobj.getDocId());
			System.out.println("Document:"+docobj.getApplication().getAppId());
			System.out.println("Document:"+docobj.getPanCard());
			System.out.println("Document:"+docobj.getVoterId());
			
			System.out.println("=============");
		}

	 }
	
	@Test
	 void updateDocumentTest()
	 {
		Document findDoc= docrepo.getDocument(205);
		System.out.println("Doc Number: "+findDoc.getDocId());
		System.out.println("Doc Voter ID: "+findDoc.getVoterId());
		System.out.println("DOc LOA: "+findDoc.getLoa());	
		System.out.println("============After Updating=========");
		findDoc.setPanCard("pancard1234.jpg");
		docrepo.updateDocument(findDoc);
		System.out.println("Doc Number: "+findDoc.getDocId());
		System.out.println("Doc Voter ID: "+findDoc.getVoterId());
		System.out.println("DOc LOA: "+findDoc.getLoa());	

	 }
	@Test
	 void deleteUserDocTest() {
		try {
			docrepo.deleteUserDoc(211);
			System.out.println("Object deleted..");
			}
			catch(Exception e) {
			System.out.println(e.getMessage());
			}
	}
}
