package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.servlet.http.HttpSession;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Document;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer2.model.Tracker;

@Repository
public class ApplicationRepoImpl extends BaseRepository implements ApplicationRepository {
	
	@PersistenceContext
	private EntityManager entityManager;


	@Transactional
	public void addApplicantDetails(Application appId) {
		super.persist(appId);
	}

	@Transactional
	public Application getApplication(Integer appId)  {
		// TODO Auto-generated method stub
		System.out.println(appId);
		return super.find(Application.class, appId);
	}
	@Transactional
	public List<Application> getAllApplications()  {
		// TODO Auto-generated method stub
		return super.findAll("Application");
	}
	
	@Transactional
	public void deleteApplication(Integer docId) {
		// TODO Auto-generated method stub
		super.remove(Application.class,docId);
	}

	@Transactional
	public void updateApplication(Application appId) {
		// TODO Auto-generated method stub
		super.merge(appId);
	}

	@Transactional
	public Tracker getTrackerByAppId(Integer appId) {
		return super.findTrackerIdByAppId(appId);
	}

	
	
}