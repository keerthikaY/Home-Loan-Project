package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer2.model.Tracker;
import com.example.demo.layer3.ApplicationRepository;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.DocumentRepository;
import com.example.demo.layer3.LoanRepository;
import com.example.demo.layer3.PropertyAndIncomeRepository;
import com.example.demo.layer3.TrackerRepo;
import com.example.demo.layer3.UserRegistrationRepo;

@Service
public class ApplicationServiceImpl implements ApplicationService {
	
	@Autowired
	ApplicationRepository apprepo;
	
	@Autowired
	BankRepository bankRepo;
	
	@Autowired
	DocumentRepository documentRepo;
	
	@Autowired
	PropertyAndIncomeRepository propertyAndIncomeRepo;
	
	@Autowired
	LoanRepository loanRepo;
	
	@Autowired
	TrackerRepo trackerRepo;
	
	@Autowired
	UserRegistrationRepo userRepo;
	
	@Override
	public List<Application> findAllApplicationService() {
		// TODO Auto-generated method stub
		return apprepo.getAllApplications();
	}

	@Override
	public void addApplicationService(Application app) {
		apprepo.addApplicantDetails(app);
	}

	@Override
	public Application getApplicationService(Integer appId) {
		// TODO Auto-generated method stub
		System.out.println(appId);
		return apprepo.getApplication(appId);
	}

	@Override
	public void deleteApplicationService(Integer appId) {
		// TODO Auto-generated method stub
		apprepo.deleteApplication(appId);
	}

	@Override
	public void updateApplicationService(Application appId) {
		// TODO Auto-generated method stub
		apprepo.updateApplication(appId);
	}

	@Override
	public Tracker gettrackerByAppId(Integer appId) {
		return apprepo.getTrackerByAppId(appId);
		
	}

	

	

}
