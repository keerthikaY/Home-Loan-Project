package com.example.demo.layer3;


import com.example.demo.layer2.model.Propertyandincome;

import java.util.*;

public interface PropertyAndIncomeRepository {
	public Propertyandincome getPropertyAndIncomeListById(Integer property_id);
	public void addPropertyAndIncomeDetails(Propertyandincome propertyAndIncome);
	public void deletePropertyAndIncome(Integer Property_id);
	public void updatePropertyAndIncome(Propertyandincome propertyAndIncome);
	public List<Propertyandincome> getAllPropertyAndIncome();
}
