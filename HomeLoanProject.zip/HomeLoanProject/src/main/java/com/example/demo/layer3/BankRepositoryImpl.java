package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;


@Repository
public class BankRepositoryImpl extends BaseRepository implements BankRepository {

	@Transactional
	public Bank getBankById(Integer accNo) {
		return super.find(Bank.class, accNo);
	}

	@Transactional
	public void addBankDetails(Bank bank) {
		super.persist(bank);
	}

	@Transactional
	public void deleteBankDetails(Integer accNo) {
		super.remove(Bank.class, accNo);
	}

	@Transactional
	public void updateBankDetails(Bank bank) {
		super.merge(bank);
	}

	@SuppressWarnings("unchecked")
	@Transactional
	public List<Bank> getAllBankDetails() {
		return super.findAll("Bank");
	}

	@Transactional
	public Application getApplicationByBankId(Long accNo) {
		return super.findApplicationByBankId(accNo);
	}

	

	
}