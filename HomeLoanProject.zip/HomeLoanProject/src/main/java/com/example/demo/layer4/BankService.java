package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;

@Service
public interface BankService {
	public List<Bank> getAllBanksService();
	public Bank getBankByIdService(Integer bankId);
	public void addBankDetailsService(Bank bank);
	public void deleteBankDetailsService(Integer accNo);
	public void updateBankDetailsService(Bank bank);
	public Application getApplicationByAccNo(Long accNo);
}
