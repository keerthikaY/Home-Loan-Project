package com.example.demo.layer5;

public class DocNotFoundException extends Exception{

	
	public DocNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public DocNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}