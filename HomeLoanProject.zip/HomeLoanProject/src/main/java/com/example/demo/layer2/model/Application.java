package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;
import java.util.Date;


/**
 * The persistent class for the APPLICATION database table.
 * 
 */
@Entity
@NamedQuery(name="Application.findAll", query="SELECT a FROM Application a")
public class Application implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="APP_ID")
	private Integer appId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="DATE_OF_APP")
	private Date dateOfApp;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="USER_ID")
	private HomeUser homeUser;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="PROPERTY_ID")
	private Propertyandincome propertyandincome;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="DOC_ID")
	private Document document;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="LOAN_ID")
	private Loan loan;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="BANK_ID")
	private Bank bank;
	
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="TRACKER_ID")
	private Tracker tracker;

	public Application() {
	}
	
	public Integer getAppId() {
		return this.appId;
	}

	public void setAppId(Integer appId) {
		this.appId = appId;
	}


	
	public Date getDateOfApp() {
		return this.dateOfApp;
	}

	public void setDateOfApp(Date dateOfApp) {
		this.dateOfApp = dateOfApp;
	}


	//bi-directional many-to-one association to HomeUser
	
	public HomeUser getHomeUser() {
		return this.homeUser;
	}

	public void setHomeUser(HomeUser homeUser) {
		this.homeUser = homeUser;
	}


	//bi-directional one-to-one association to Propertyandincome
	
	
	public Propertyandincome getPropertyandincome() {
		return this.propertyandincome;
	}

	public void setPropertyandincome(Propertyandincome propertyandincome) {
		this.propertyandincome = propertyandincome;
	}


	//bi-directional one-to-one association to Document
	
	
	public Document getDocument() {
		return this.document;
	}

	public void setDocument(Document document) {
		this.document = document;
	}


	//bi-directional one-to-one association to Loan
	
	
	public Loan getLoan() {
		return this.loan;
	}

	public void setLoan(Loan loan) {
		this.loan = loan;
	}


	//bi-directional one-to-one association to Bank
	
	
	public Bank getBank() {
		return this.bank;
	}

	public void setBank(Bank bank) {
		this.bank = bank;
	}


	//bi-directional one-to-one association to Tracker
	
	
	public Tracker getTracker() {
		return this.tracker;
	}

	public void setTracker(Tracker tracker) {
		this.tracker = tracker;
	}

}