package com.example.demo.layer3;

import java.io.Serializable;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.Tracker;


@Repository
public class BaseRepository {
	
	@PersistenceContext
	EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}
	
	public BaseRepository() {
		System.out.println("BaseRepository()....");
	}
	
	@Transactional
	public void persist(Object obj) { //persist is a dummy/userdefined name
		
		try {
				entityManager.persist(obj);			
		} finally { entityManager.close(); }

	}
	
	@Transactional
	public <AnyClass> AnyClass find(Class<AnyClass> theClass, Serializable pk ) {
		AnyClass foundSavingsAccObj = null;
		try {			
			foundSavingsAccObj = entityManager.find(theClass, pk);	
		} finally { entityManager.close(); }
			return foundSavingsAccObj;
	}
	
	
	
	@Transactional
	public <E> List  findAll(String pojoName) {
		try {			
			Query query = entityManager.createQuery(" from "+ pojoName);
			return query.getResultList();
		} finally { entityManager.close(); }
	}
	
	@Transactional
	public void merge(Object obj) {
		
		try {
			entityManager.merge(obj); //<--real call for jdbc here		
		} finally { entityManager.close(); }
		
	}
	
	
	
	@Transactional
	public <AnyClass> void remove(Class<AnyClass> theClass, Serializable pk) {
	try {
		AnyClass anyClass = entityManager.find(theClass, pk);
		if(anyClass==null) {
			throw new RuntimeException("Object not found to delete");
		}
		entityManager.remove(anyClass);
		} finally { entityManager.close(); }
	}
	
	@Transactional
	public HomeUser findUserByEmail(String email,String pass) {

	try {
	  Query query=entityManager.createQuery("select u from HomeUser u where u.email='"+email+"'and u.password='"+pass+"'");
	return (HomeUser)query.getSingleResult();
	}
	finally {
	entityManager.close();
	}
	}
	
	@Transactional
	public Tracker findTrackerIdByAppId(Integer appId) {

	try {
	  Query query=entityManager.createQuery("select Tracker from Application a where a.appId='"+appId+"'");
	  System.out.println((Integer)query.getSingleResult());
	return (Tracker)query.getSingleResult();
	}
	finally {
	entityManager.close();
	}
	
	}	
	@Transactional
	public Bank findBankByaccNo(Integer accNo) {

	try {
	  Query query=entityManager.createQuery("select b from Bank b where b.accNo='"+accNo+"'");
	  System.out.println((Integer)query.getSingleResult());
	return (Bank)query.getSingleResult();
	}
	finally {
	entityManager.close();
	}
	
	}	
	@Transactional
	public Application findApplicationByBankId(Long accNo) {

	try {
	  Query query=entityManager.createQuery("select a from Application a where a.bank.accNo='"+accNo+"'");
	  //System.out.println((Integer)query.getSingleResult());
	return (Application)query.getSingleResult();
	}
	finally {
	entityManager.close();
	}

	}	
	@Transactional
	public Loan findLoanByAppId(Integer appId) {

	try {
	  Query query=entityManager.createQuery("select loan from Application a where a.appId='"+appId+"'");
	  //System.out.println((Integer)query.getSingleResult());
	return (Loan)query.getSingleResult();
	}
	finally {
	entityManager.close();
	}

	}	
	
	
	
	
}