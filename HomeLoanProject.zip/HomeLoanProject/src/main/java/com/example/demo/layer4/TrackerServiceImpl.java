package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Tracker;
import com.example.demo.layer3.TrackerRepo;

@Service
public class TrackerServiceImpl implements TrackerService {
	
	@Autowired
	TrackerRepo trackrepo;
	
	@Override
	public List<Tracker> findAllTrackerService() {
		// TODO Auto-generated method stub
		return trackrepo.getAllTrackerDetails();
	}

	@Override
	public void addTrackerService(Tracker tracker) {
		// TODO Auto-generated method stub
		trackrepo.addTrackerDetails(tracker);
	}

	@Override
	public Tracker getTrackerService(Integer trackerId) {
		// TODO Auto-generated method stub
		System.out.println(trackerId);
		return trackrepo.getTrackerDetailsById(trackerId);
		}

}