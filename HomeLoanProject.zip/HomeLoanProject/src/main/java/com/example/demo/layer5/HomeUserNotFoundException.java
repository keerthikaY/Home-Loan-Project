package com.example.demo.layer5;

public class HomeUserNotFoundException extends Exception{
    public HomeUserNotFoundException(String msg) {
    	super(msg);
    }
}
