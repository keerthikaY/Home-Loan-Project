package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer3.UserRegistrationRepo;

@Service
public class HomeUserServiceImpl implements HomeUserService {
	@Autowired
	UserRegistrationRepo userRepo;
	

	@Override
	public List<HomeUser> findAllHomeUsers() {
		// TODO Auto-generated method stub
		return userRepo.getAllHomeUser();
	}
	@Override
	public void addHomeDetailsService(HomeUser homeUser) {
		userRepo.addHomeUser(homeUser);
		
		
	}
	@Override
	public HomeUser findHomeById(Integer userId) {
		System.out.println("finding");
		return userRepo.getHomeUser(userId);
	}
	@Override
	public void DeleteUserService(Integer userId) {
		try {
			userRepo.deleteHomeUser(userId);
		}
		catch(Exception e){
			System.out.println(e);
		}
	}
	@Override
	public void UpdateUserService(HomeUser homeUser) {
		userRepo.updateHomeUser(homeUser);
	}
	@Override
	public HomeUser getUserByEmailAndPassService(String email,String pass) {
		HomeUser user=userRepo.findUserByEmail(email, pass);
		if(user==null) {
			System.out.println("Register...not valid user");
		}
		return user;
	}
	@Override
	public HomeUser findUserByEmailService(String email) {
		return userRepo.findUserByEmail(email);
	}
	
	
	
	

}