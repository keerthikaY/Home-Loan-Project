package com.example.demo.layer3;

import java.util.List;

import com.example.demo.layer2.model.Document;

public interface DocumentRepository {

	 void addUserDoc(Document doc);
	 Document getDocument(Integer docId);
	 List<Document> getAllUserDocuments();
	 void deleteUserDoc(Integer docId);
	 void updateDocument(Document docId);
	 Integer getDocIdByPanCard(String pan);
}
