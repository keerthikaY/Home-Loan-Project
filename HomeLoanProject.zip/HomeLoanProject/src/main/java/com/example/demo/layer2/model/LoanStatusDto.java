package com.example.demo.layer2.model;

import java.util.Date;

public class LoanStatusDto {
  private String status;
  private Date aprrovedDate;
  
public Date getAprrovedDate() {
	return aprrovedDate;
}

public void setAprrovedDate(Date aprrovedDate) {
	this.aprrovedDate = aprrovedDate;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}
}
