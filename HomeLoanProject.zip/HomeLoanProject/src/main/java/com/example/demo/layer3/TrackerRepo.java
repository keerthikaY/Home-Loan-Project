package com.example.demo.layer3;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Document;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer2.model.Tracker;

public interface TrackerRepo {

	public Tracker getTrackerDetailsById(Integer trackerId );
	public void addTrackerDetails(Tracker tracker);
	public List<Tracker> getAllTrackerDetails();
}