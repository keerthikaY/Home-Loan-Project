package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Propertyandincome;

@Service
public interface PropertyandIncomeService {
	public List<Propertyandincome> getAllPropertyAndIncomeService();
	public Propertyandincome getPropertyAndIncomeByIdService(Integer propertyId);
	public void addPropertyAndIncomeService(Propertyandincome propertyAndIncome);
	public void deletePropertyAndIncomeService(Integer propertyId);
	public void updatePropertyAndIncomeService(Propertyandincome propertyAndIncome);
}
