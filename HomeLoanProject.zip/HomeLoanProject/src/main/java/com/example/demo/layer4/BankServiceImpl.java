package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer3.BankRepository;

@Service
public class BankServiceImpl implements BankService{

	
	@Autowired
	BankRepository bankRepo;
	
	@Override
	public List<Bank> getAllBanksService() {
		return bankRepo.getAllBankDetails();
	}

	@Override
	public Bank getBankByIdService(Integer bankId) {
		return bankRepo.getBankById(bankId);
	}

	@Override
	public void addBankDetailsService(Bank bank) {
		bankRepo.addBankDetails(bank);
	}

	@Override
	public void deleteBankDetailsService(Integer accNo) {
		try {
			bankRepo.deleteBankDetails(accNo);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void updateBankDetailsService(Bank bank) {
		bankRepo.updateBankDetails(bank);
	}

	@Override
	public Application getApplicationByAccNo(Long accNo) {
		return bankRepo.getApplicationByBankId(accNo);
	}

}
