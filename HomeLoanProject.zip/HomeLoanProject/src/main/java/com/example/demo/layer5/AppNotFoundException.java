package com.example.demo.layer5;

public class AppNotFoundException extends Exception{

	
	public AppNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AppNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}