package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Tracker;
@Service
public interface ApplicationService {
	List<Application> findAllApplicationService();
	 void addApplicationService(Application app);
	 Application getApplicationService(Integer appId);
	 void deleteApplicationService(Integer appId);
	 void updateApplicationService(Application  appId);
	 Tracker gettrackerByAppId(Integer appId);
	 
}
