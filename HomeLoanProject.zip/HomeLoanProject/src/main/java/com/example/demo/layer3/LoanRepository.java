package com.example.demo.layer3;

import java.util.List;

import javax.servlet.http.HttpSession;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Document;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.Propertyandincome;

public interface LoanRepository {

	public Loan getLoanDetailsById(Integer loanId );
	public void addLoanDetails(Loan loan);
	public List<Loan> getAllLoanDetails();
	public void deleteLoanDetails(Integer loanId);
	public void updateLoanDetails(Loan findObj);
	public Loan getLoanByAppId(Integer appId);
	
}