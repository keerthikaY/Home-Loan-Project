package com.example.demo.layer5;

public class BankNotFoundException extends Exception{
  public BankNotFoundException(String msg) {
	  super(msg);
  }
}
