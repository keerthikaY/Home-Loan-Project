package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer4.HomeUserService;

@CrossOrigin(origins="",value="")
@RestController
public class UserRegistrationJPAController {
	
	@Autowired
	HomeUserService homeuserservice;
	
	@GetMapping
	@RequestMapping(path="/getJPAHomeDetails")
	public List<HomeUser>getAllHome(){
		System.out.println("getting");
		return homeuserservice.findAllHomeUsers();
	}
	@GetMapping
	@RequestMapping(path="/getJPAHome/{userId}")
	public HomeUser getHome(@PathVariable("userId")Integer userIdToFind) {
		System.out.println("finding"+userIdToFind);
		HomeUser foundHome=null;
		foundHome=homeuserservice.findHomeById(userIdToFind);
		if(foundHome==null) {
			System.out.println("not found");
		}
		return foundHome;
		
	}
	@PostMapping
	@RequestMapping(path="/addJPAHome")
	public void addHomeUser(@RequestBody HomeUser UserToInsert)
	{
		HomeUser homeObj= new HomeUser();
		homeObj.setFirstName(UserToInsert.getFirstName());
		homeObj.setMiddleName(UserToInsert.getMiddleName());
		homeObj.setLastName(UserToInsert.getLastName());
		homeObj.setAdhaarNo(UserToInsert.getAdhaarNo());
		homeObj.setPanNo(UserToInsert.getPanNo());
		homeObj.setDob(UserToInsert.getDob());
		homeObj.setEmail(UserToInsert.getEmail());
		homeObj.setNationality(UserToInsert.getNationality());
		homeObj.setPassword(UserToInsert.getPassword());
		homeObj.setPhoneNo(UserToInsert.getPhoneNo());
		homeObj.setGender(UserToInsert.getGender());
		homeuserservice.addHomeDetailsService(homeObj);
	}
	@PostMapping
	@RequestMapping(path="/deleteJPAHome")
	public void deleteUser(@RequestBody HomeUser homeuser)throws HomeUserNotFoundException{
		System.out.println("deleting"+homeuser.getUserId());
		boolean found= false;
		if(found) {
			System.out.println("deleted");
			
		}
		else {
			System.out.println("not found");
			HomeUserNotFoundException exc= new HomeUserNotFoundException("not found"+homeuser.getUserId());
			throw exc;
		}
	}
		
		@PostMapping
		@RequestMapping(path="/updateJPAHome")
		public void updateHome(@RequestBody HomeUser home)throws HomeUserNotFoundException {
			System.out.println("modify "+home.getFirstName());
			boolean found2= false;
			homeuserservice.UpdateUserService(home);
			found2=true;
			if(found2) {
				System.out.println("modified");
			}
			else {
				System.out.println("not found");
				HomeUserNotFoundException exc1= new HomeUserNotFoundException("not found"+home.getUserId());
				throw exc1;
			}
		}
	
		@PostMapping
		@RequestMapping(path="/login/{email}/{password}")
		public HomeUser getPass(@PathVariable("email")String email,@PathVariable("password")String password) {
			boolean found=false;
			HomeUser userlogin=homeuserservice.getUserByEmailAndPassService(email,password);
			found=true;
			if(found) {
				System.out.println("found");
			}
			else {
				System.out.println("register");
			}
			return userlogin;
		}
			
		
	
}