package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the PROPERTYANDINCOME database table.
 * 
 */
@Entity
@NamedQuery(name="Propertyandincome.findAll", query="SELECT p FROM Propertyandincome p")
public class Propertyandincome implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="PROPERTY_ID")
	private Integer propertyId;
	
	@Column(name="EMPLOYER_NAME")
	private String employerName;
	
	@Column(name="ESTIMATED_AMT")
	private Long estimatedAmt;
	
	@Column(name="INCOME")
	private Long income;
	
	@Column(name="ORG_TYPE")
	private String orgType;
	
	@Column(name="PROPERTY_LOC")
	private String propertyLoc;
	
	@Column(name="PROPERTY_NAME")
	private String propertyName;
	
	@Column(name="RET_AGE")
	private Integer retAge;
	
	@Column(name="TYPE_OF_EMP")
	private String typeOfEmp;
	
	@OneToOne(mappedBy="propertyandincome")
	private Application application;

	public Propertyandincome() {
	}


	
	public Integer getPropertyId() {
		return this.propertyId;
	}

	public void setPropertyId(Integer propertyId) {
		this.propertyId = propertyId;
	}


	public String getEmployerName() {
		return this.employerName;
	}

	public void setEmployerName(String employerName) {
		this.employerName = employerName;
	}


	public Long getEstimatedAmt() {
		return this.estimatedAmt;
	}

	public void setEstimatedAmt(Long estimatedAmt) {
		this.estimatedAmt = estimatedAmt;
	}


	public Long getIncome() {
		return this.income;
	}

	public void setIncome(Long income) {
		this.income = income;
	}


	
	public String getOrgType() {
		return this.orgType;
	}

	public void setOrgType(String orgType) {
		this.orgType = orgType;
	}


	public String getPropertyLoc() {
		return this.propertyLoc;
	}

	public void setPropertyLoc(String propertyLoc) {
		this.propertyLoc = propertyLoc;
	}


	public String getPropertyName() {
		return this.propertyName;
	}

	public void setPropertyName(String propertyName) {
		this.propertyName = propertyName;
	}


	public Integer getRetAge() {
		return this.retAge;
	}

	public void setRetAge(Integer retAge) {
		this.retAge = retAge;
	}


	public String getTypeOfEmp() {
		return this.typeOfEmp;
	}

	public void setTypeOfEmp(String typeOfEmp) {
		this.typeOfEmp = typeOfEmp;
	}


	//bi-directional one-to-one association to Application
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}