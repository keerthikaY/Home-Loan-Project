package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.model.Document;
import com.example.demo.layer4.DocumentService;

@CrossOrigin(origins = "*", value = "*")
@RestController
public class DocumentJPAController {
    
	@Autowired
	DocumentService docService;
	
	@GetMapping
	@RequestMapping(path="/getJPAallDocs") //localhost:8080/getDepts
	public List<Document> getAllDocDetailss() {
		System.out.println("getAllDocuments");
		return docService.findAllDocumentsService();
	}
	
	@GetMapping
	@RequestMapping(path="/getJPADoc/{docId}") // localhost:8080/getDept/10
	public Document getDocument(@PathVariable("docId") int docIdToFind) throws DocNotFoundException 
	{
		System.out.println("getDocument : "+docIdToFind);
		Document founddoc = null;
		founddoc = docService.getDocumentService(docIdToFind);
	
		if(founddoc == null) {
			DocNotFoundException d = new DocNotFoundException("Document  Not Found "+docIdToFind);
		}
		
		return founddoc;
	}
	
	@PostMapping
	@RequestMapping(path="/addDocument")
	public void addDocument(@RequestBody Document DocToInsert) {
		Document docobj=new Document();
		docobj.setAgreementToSale(DocToInsert.getAgreementToSale());
		docobj.setLoa(DocToInsert.getLoa());
		docobj.setNocFromBuilder(DocToInsert.getNocFromBuilder());
		docobj.setPanCard(DocToInsert.getPanCard());
		docobj.setSalarySlip(DocToInsert.getSalarySlip());
		docobj.setVoterId(DocToInsert.getVoterId());
		docService.addUserDocService(docobj);
	}
	
	@PostMapping
	@RequestMapping(path="/updateDocument")
	public void updateDocument(@RequestBody Document doc) throws DocNotFoundException{
		System.out.println("modify Pan Card :"+doc.getPanCard());
		boolean found=false;
		docService.updateDocumentService(doc);
		found=true;
		if(found) {
			System.out.println("Record modified");
		}
		else {
			System.out.println("Not Found");
			DocNotFoundException exception=new DocNotFoundException("Not Found"+doc.getPanCard());
			throw exception;
		}
	}
	
	@PostMapping
	@RequestMapping(path="/deleteJPADoc") // localhost:8080/deleteDept/10
	public void deleteDocument(@RequestBody Document doc) throws DocNotFoundException 
	{
		System.out.println("deleteDocument : "+doc.getDocId()); 
		boolean found=false;
		
		docService.deleteUserDocService(doc.getDocId());
		found=true;
			
		
		if(found) {
			System.out.println("Doc Deleted");
		}
		else {
			System.out.println("Not found");
			DocNotFoundException docNotFoundEx = new DocNotFoundException("Department Number Not Found "+doc.getDocId());
			throw docNotFoundEx;
		}
		
	}


}
