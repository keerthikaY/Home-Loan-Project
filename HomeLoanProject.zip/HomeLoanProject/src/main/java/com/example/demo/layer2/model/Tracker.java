package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Date;


/**
 * The persistent class for the TRACKER database table.
 * 
 */
@Entity
@NamedQuery(name="Tracker.findAll", query="SELECT t FROM Tracker t")
public class Tracker implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="TRACKER_ID")
	private Integer trackerId;
	
	@Temporal(TemporalType.DATE)
	@Column(name="APRROVED_DATE")
	private Date aprrovedDate;
	
	@Column(name="STATUS")
	private String status;
	
	@OneToOne(mappedBy="tracker", cascade=CascadeType.ALL)
	private Application application;

	public Tracker() {
	}


	
	public Integer getTrackerId() {
		return this.trackerId;
	}

	public void setTrackerId(Integer trackerId) {
		this.trackerId = trackerId;
	}


	
	public Date getAprrovedDate() {
		return this.aprrovedDate;
	}

	public void setAprrovedDate(Date aprrovedDate) {
		this.aprrovedDate = aprrovedDate;
	}


	public String getStatus() {
		return this.status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


	//bi-directional one-to-one association to Application
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}