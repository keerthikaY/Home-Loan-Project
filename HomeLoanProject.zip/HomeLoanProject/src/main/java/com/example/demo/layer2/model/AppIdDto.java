package com.example.demo.layer2.model;

public class AppIdDto {
   private Integer appId;

public Integer getAppId() {
	return appId;
}

public void setAppId(Integer appId) {
	this.appId = appId;
}
}
