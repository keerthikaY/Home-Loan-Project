package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer3.PropertyAndIncomeRepository;

@Service
public class PropertyAndIncomeServiceImpl implements PropertyandIncomeService{
   
	
	@Autowired
	PropertyAndIncomeRepository propertyRepo;
	
	@Override
	public List<Propertyandincome> getAllPropertyAndIncomeService() {
		return propertyRepo.getAllPropertyAndIncome();
	}

	@Override
	public Propertyandincome getPropertyAndIncomeByIdService(Integer propertyId) {
		return propertyRepo.getPropertyAndIncomeListById(propertyId);
	}

	@Override
	public void addPropertyAndIncomeService(Propertyandincome propertyAndIncome) {
		propertyRepo.addPropertyAndIncomeDetails(propertyAndIncome);
	}

	@Override
	public void deletePropertyAndIncomeService(Integer propertyId) {
		try {
			propertyRepo.deletePropertyAndIncome(propertyId);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void updatePropertyAndIncomeService(Propertyandincome propertyAndIncome) {
		propertyRepo.updatePropertyAndIncome(propertyAndIncome);
	}

}
