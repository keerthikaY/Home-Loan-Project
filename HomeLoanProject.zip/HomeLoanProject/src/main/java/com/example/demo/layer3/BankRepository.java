package com.example.demo.layer3;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;

public interface BankRepository {
	public Bank getBankById(Integer accNo);
	public void addBankDetails(Bank bank);
	public void deleteBankDetails(Integer accNo);
	public void updateBankDetails(Bank bank);
	public List<Bank> getAllBankDetails();
	
	public Application getApplicationByBankId(Long accNo);
}
