package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Document;

@Service
public interface DocumentService {
	List<Document> findAllDocumentsService();
	 void addUserDocService(Document doc);
	 Document getDocumentService(Integer docId);
	 void deleteUserDocService(Integer docId);
	 void updateDocumentService(Document docId);
}