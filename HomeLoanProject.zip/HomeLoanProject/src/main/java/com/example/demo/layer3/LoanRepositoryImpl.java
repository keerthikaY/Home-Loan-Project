package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.model.Loan;

@Repository
public class LoanRepositoryImpl extends BaseRepository implements LoanRepository{
	
	
	@PersistenceContext
	private EntityManager entityManager;


	@Transactional
	public Loan getLoanDetailsById(Integer loanId) {
		// TODO Auto-generated method stub
	System.out.println("returning");	
		return super.find(Loan.class,loanId);
	}

	
	@Transactional
	public void addLoanDetails(Loan loan) {
		// TODO Auto-generated method stub
		super.persist(loan);

	}


	@Transactional
	public List<Loan> getAllLoanDetails() {
		// TODO Auto-generated method stub
		return super.findAll("Loan");
	}

	
	@Transactional
	public void deleteLoanDetails(Integer loanId) {
		// TODO Auto-generated method stub
		super.remove(Loan.class, loanId);
		
	}

	@Transactional
	public void updateLoanDetails(Loan findObj) {
		// TODO Auto-generated method stub
		super.merge(findObj);
	}


	@Transactional
	public Loan getLoanByAppId(Integer appId) {
		return super.findLoanByAppId(appId);
	}


}