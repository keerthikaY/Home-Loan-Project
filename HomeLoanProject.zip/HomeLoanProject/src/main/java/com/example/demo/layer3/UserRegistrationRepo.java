package com.example.demo.layer3;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.example.demo.layer2.model.HomeUser;

public interface UserRegistrationRepo {
	public HomeUser getHomeUser(Integer userId);
	public void addHomeUser(HomeUser homeuser);
	public void updateHomeUser(HomeUser homeuser);
	public void deleteHomeUser(Integer userId);
	public List<HomeUser>getAllHomeUser();
    
	public HomeUser findUserByEmail(String email,String pass);
	public HomeUser findUserByEmail(String email);//adding user in application

}