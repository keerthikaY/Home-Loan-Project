package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Document;
import com.example.demo.layer3.DocumentRepository;

@Service
public class DocumentServiceImpl implements DocumentService {
	
	@Autowired
	DocumentRepository docrepo;
	@Override
	public List<Document> findAllDocumentsService() {
		// TODO Auto-generated method stub
		
		return docrepo.getAllUserDocuments();
	}
	@Override
	public void addUserDocService(Document doc) {
		// TODO Auto-generated method stub
		docrepo.addUserDoc(doc);
	}
	@Override
	public Document getDocumentService(Integer docId) {
		// TODO Auto-generated method stub
		System.out.println(docId);
		return docrepo.getDocument(docId);
	}
	@Override
	public void deleteUserDocService(Integer docId) {
		// TODO Auto-generated method stub
		docrepo.deleteUserDoc(docId);
	}
	@Override
	public void updateDocumentService(Document docId) {
		// TODO Auto-generated method stub
		docrepo.updateDocument(docId);
	}
	//@Override
	/*public void addUserDocService(Document doc) {
		// TODO Auto-generated method stub
		Document de=doc;
		docrepo.addUserDoc(doc);
		docrepo.getDocIdByPanCard(de.getPanCard());
	}*/

}
