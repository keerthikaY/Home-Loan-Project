package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.model.Loan;
import com.example.demo.layer4.LoanService;

@CrossOrigin(origins = "", value = "")
@RestController
public class LoanJPAController {
    
	@Autowired
	LoanService loanService;
	
	@GetMapping
	@RequestMapping(path="/getJPALoanDetails") //localhost:8080/getDepts
	public List<Loan> getAllLoanDetails() {
		System.out.println("allLoanDetails");
		return loanService.getAllLoanDetailsService();
	}
	
	
	@PostMapping
	@RequestMapping(path="/updateLoan")
	public void updateLoanDetails(@RequestBody Loan loan) throws LoanNotFoundException{
		System.out.println("modify Loan :"+loan.getLoanId());
		boolean found=false;
		loanService.updateLoanDetailsService(loan);
		found=true;
		if(found) {
			System.out.println("Record modified");
		}
		else {
			System.out.println("Not Found");
			LoanNotFoundException exception=new LoanNotFoundException("Not Found"+loan.getLoanId());
			throw exception;
		}
	}
	
	
	@GetMapping
	@RequestMapping(path="/getJPALoanById/{loanId}") //localhost:8080/getDepts
	public Loan getLoan(@PathVariable("loanId") Integer loanById) throws LoanNotFoundException 
	{
		System.out.println("getLoan : "+loanById);
		Loan foundLoan = null;
		foundLoan = loanService.getLoanDetailsByIdService(loanById);
	
		if(foundLoan == null) {
			LoanNotFoundException d = new LoanNotFoundException("Loan Details Not Found "+loanById);
		}

		return foundLoan;
	}
	
	/*@PostMapping
	@RequestMapping(path="/addLoan/{AccNo}/{bankName}/{bankIfscCode}")
	public void addLoan(@PathVariable("bankAccNo") Long addBankAccNo,@PathVariable("bankName") String addBankName,@PathVariable("bankIfscCode") String addBankIfscCode) {
		Loan loanObj=new Loan();
		loanObj.setAccNo(addBankAccNo);
		loanObj.setBankName(addBankName);
		loanObj.setIfscCode(addBankIfscCode);
		loanService.addLoanDetailsService(loanObj);
	}*/
	
	@PostMapping
	@RequestMapping(path="/addLoan2")
	public void addLoan(@RequestBody Loan LoanToInsert) {
		Loan loanObj=new Loan();
		loanObj.setApplication(null);
		loanObj.setTenure(LoanToInsert.getTenure());
		loanObj.setLoanAmount(LoanToInsert.getLoanAmount());
		loanObj.setRoi(LoanToInsert.getRoi());
		loanObj.setEmi(LoanToInsert.getEmi());
		loanService.addLoanDetailsService(loanObj);
	}
	
	@PostMapping
	@RequestMapping(path="/deleteJPALoan")
	public void deleteLoan(@RequestBody Loan loan) throws LoanNotFoundException{
		System.out.println("delete Loan: "+loan.getLoanId());
		boolean found=false;
		loanService.deleteLoanDetailsService(loan.getLoanId());
		if(found) {
			System.out.println("Loan deleted");
		}
		else {
			System.out.println("Not Found");
			LoanNotFoundException exc=new LoanNotFoundException("Not found "+loan.getLoanId());
			throw exc;
		}
	}
	@GetMapping
	@RequestMapping(path="/getJLoanByAppId/{appId}") //localhost:8080/getDepts
	public Loan getLoanByAppId(@PathVariable("appId") Integer appId) throws LoanNotFoundException 
	{
		Loan l=loanService.getLoanDetailsByIdService(appId);
		return l;
	}

	
	
	
}