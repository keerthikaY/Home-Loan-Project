package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer4.BankService;

@CrossOrigin(origins = "*", value = "*")
@RestController
public class BankJPAController {
    
	@Autowired
	BankService bankService;
	
	@GetMapping
	@RequestMapping(path="/getJPABankDetails") //localhost:8080/getDepts
	public List<Bank> getAllBankDetailss() {
		System.out.println("getAllDepartments");
		return bankService.getAllBanksService();
	}
	
	@GetMapping
	@RequestMapping(path="/getJPABankById/{bankId}") //localhost:8080/getDepts
	public Bank getBank(@PathVariable("bankId") Integer bankById) throws BankNotFoundException 
	{
		System.out.println("getBank : "+bankById);
		Bank foundBank = null;
		foundBank = bankService.getBankByIdService(bankById);
	
		if(foundBank == null) {
			BankNotFoundException d = new BankNotFoundException("Department Number Not Found "+bankById);
		}

		return foundBank;
	}
	
	@PostMapping
	@RequestMapping(path="/addBank/{AccNo}/{bankName}/{bankIfscCode}")
	public void addBank(@PathVariable("bankAccNo") Long addBankAccNo,@PathVariable("bankName") String addBankName,@PathVariable("bankIfscCode") String addBankIfscCode) {
		Bank bankObj=new Bank();
		bankObj.setAccNo(addBankAccNo);
		bankObj.setBankName(addBankName);
		bankObj.setIfscCode(addBankIfscCode);
		bankObj.setApplication(null);
		bankService.addBankDetailsService(bankObj);
	}
	
	@PostMapping
	@RequestMapping(path="/addBank2")
	public void addBank(@RequestBody Bank BankToInsert) {
		Bank bankObj=new Bank();
		bankObj.setAccNo(BankToInsert.getAccNo());
		bankObj.setBankName(BankToInsert.getBankName());
		bankObj.setIfscCode(BankToInsert.getIfscCode());
		bankService.addBankDetailsService(bankObj);
	}
	
	@PostMapping
	@RequestMapping(path="/deleteJPABank")
	public void deleteBank(@RequestBody Bank bank) throws BankNotFoundException{
		System.out.println("delete Bank: "+bank.getBankId());
		boolean found=false;
		bankService.deleteBankDetailsService(bank.getBankId());
		if(found) {
			System.out.println("Bank deleted");
		}
		else {
			System.out.println("Not Found");
			BankNotFoundException exc=new BankNotFoundException("Not found "+bank.getBankId());
			throw exc;
		}
	}
	
	@PostMapping
	@RequestMapping(path="/updateBank")
	public void updateBank(@RequestBody Bank bank) throws BankNotFoundException{
		System.out.println("modify Bank Name :"+bank.getBankName());
		boolean found=false;
		bankService.updateBankDetailsService(bank);
		found=true;
		if(found) {
			System.out.println("Record modified");
		}
		else {
			System.out.println("Not Found");
			BankNotFoundException exception=new BankNotFoundException("Not Found"+bank.getBankId());
			throw exception;
		}
	}
	@PostMapping
	@RequestMapping(path="/getApplicationByAccNo/{accNo}")
	public Application getApplicationByAccNo(@PathVariable("accNo") Long accNo) throws BankNotFoundException{
		   Application app=bankService.getApplicationByAccNo(accNo);
		   return app;
		}
	}
	
	
	
	

