package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the BANK database table.
 * 
 */
@Entity
@NamedQuery(name="Bank.findAll", query="SELECT b FROM Bank b")
public class Bank implements Serializable {
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="BANK_ID")
	private Integer bankId;
	
	@Column(name="ACC_NO")
	private Long accNo;
	
	@Column(name="BANK_NAME")
	private String bankName;
	
	@Column(name="IFSC_CODE")
	private String ifscCode;
	
	@OneToOne(mappedBy="bank")
	private Application application;

	public Bank() {
	}

	
	public Integer getBankId() {
		return this.bankId;
	}
	
	public void setBankId(Integer bankId) {
		this.bankId=bankId;
	}
	
	public Long getAccNo() {
		return this.accNo;
	}

	public void setAccNo(Long accNo) {
		this.accNo = accNo;
	}


	public String getBankName() {
		return this.bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}


	
	public String getIfscCode() {
		return this.ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}


	//bi-directional one-to-one association to Application
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}