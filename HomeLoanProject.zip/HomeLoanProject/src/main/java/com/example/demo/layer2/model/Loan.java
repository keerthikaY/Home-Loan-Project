package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;

import java.math.BigDecimal;


/**
 * The persistent class for the LOAN database table.
 * 
 */
@Entity
@NamedQuery(name="Loan.findAll", query="SELECT l FROM Loan l")
public class Loan implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="LOAN_ID")
	private Integer loanId;
	
	@Column(name="EMI")
	private Double emi;
	
	@Column(name="LOAN_AMOUNT")
	private Long loanAmount;
	
	@Column(name="ROI")
	private Double roi;
	
	@Column(name="TENURE")
	private Integer tenure;
	
	@OneToOne(mappedBy="loan",cascade=CascadeType.ALL)
	private Application application;

	public Loan() {
	}


	
	public Integer getLoanId() {
		return this.loanId;
	}

	public void setLoanId(Integer loanId) {
		this.loanId = loanId;
	}


	public Double getEmi() {
		return this.emi;
	}

	public void setEmi(Double emi) {
		this.emi = emi;
	}


	
	public Long getLoanAmount() {
		return this.loanAmount;
	}

	public void setLoanAmount(Long loanAmount) {
		this.loanAmount = loanAmount;
	}


	public Double getRoi() {
		return this.roi;
	}

	public void setRoi(Double roi) {
		this.roi = roi;
	}


	public Integer getTenure() {
		return this.tenure;
	}

	public void setTenure(Integer tenure) {
		this.tenure = tenure;
	}


	//bi-directional one-to-one association to Application
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}