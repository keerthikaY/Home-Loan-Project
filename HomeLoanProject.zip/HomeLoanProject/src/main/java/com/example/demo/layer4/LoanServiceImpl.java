package com.example.demo.layer4;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Loan;
import com.example.demo.layer3.LoanRepository;

@Service
public class LoanServiceImpl implements LoanService {
	
	@Autowired
	LoanRepository loanRepo;

	@Override
	public Loan getLoanDetailsByIdService(Integer loanId) {
		// TODO Auto-generated method stub
		return loanRepo.getLoanDetailsById(loanId);
	}

	@Override
	public void addLoanDetailsService(Loan loan) {
		// TODO Auto-generated method stub
		loanRepo.addLoanDetails(loan);
	}

	@Override
	public List<Loan> getAllLoanDetailsService() {
		// TODO Auto-generated method stub
		return loanRepo.getAllLoanDetails();
	}

	@Override
	public void deleteLoanDetailsService(Integer loanId) {
		// TODO Auto-generated method stub
		try {
			loanRepo.deleteLoanDetails(loanId);
		}
		catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void updateLoanDetailsService(Loan findObj) {
		// TODO Auto-generated method stub
		loanRepo.updateLoanDetails(findObj);
	}

	@Override
	public Loan getLoanByAppId(Integer appId) {
		return loanRepo.getLoanByAppId(appId);
	}

}