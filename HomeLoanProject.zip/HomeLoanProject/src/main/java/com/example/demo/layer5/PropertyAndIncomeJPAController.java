package com.example.demo.layer5;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer4.BankService;
import com.example.demo.layer4.PropertyandIncomeService;

@CrossOrigin(origins = "*", value = "*")
@RestController
public class PropertyAndIncomeJPAController {
    
	@Autowired
	PropertyandIncomeService propertyService;
	
	@GetMapping
	@RequestMapping(path="/getJPAPropertyAndIncome") //localhost:8080/getDepts
	public List<Propertyandincome> getAllPropertyAndIncome() {
		System.out.println("getAllDepartments");
		return propertyService.getAllPropertyAndIncomeService();
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAPropertyAndIncomeById/{propertyId}") //localhost:8080/getDepts
	public Propertyandincome getBank(@PathVariable("propertyId") Integer propertyById) throws BankNotFoundException 
	{
		System.out.println("getBank : "+propertyById);
		Propertyandincome foundproperty = null;
		foundproperty = propertyService.getPropertyAndIncomeByIdService(propertyById);
	
		if(foundproperty == null) {
			BankNotFoundException d = new BankNotFoundException("Department Number Not Found "+propertyById);
		}

		return foundproperty;
	}
	
	/*@PostMapping
	@RequestMapping(path="/addproperty/{propertyLoc}/{propertyName}/{estimatedAmt}/{Type_Of_Emp}/{Ret_age}/{org_type}/{Emp_name}/{income}")
	public void addProperty(@PathVariable("bankAccNo") Long addBankAccNo,@PathVariable("bankName") String addBankName,@PathVariable("bankIfscCode") String addBankIfscCode) {
		Propertyandincome propertyObj=new Propertyandincome();
		propertyService.addPropertyAndIncomeService(propertyObj);
	}
	
	@PostMapping
	@RequestMapping(path="/addBank2")
	public void addBank(@RequestBody Bank BankToInsert) {
		Bank bankObj=new Bank();
		bankObj.setAccNo(BankToInsert.getAccNo());
		bankObj.setBankName(BankToInsert.getBankName());
		bankObj.setIfscCode(BankToInsert.getIfscCode());
		bankService.addBankDetailsService(bankObj);
	}
	
	@PostMapping
	@RequestMapping(path="/deleteJPABank")
	public void deleteBank(@RequestBody Bank bank) throws BankNotFoundException{
		System.out.println("delete Bank: "+bank.getBankId());
		boolean found=false;
		bankService.deleteBankDetailsService(bank.getBankId());
		if(found) {
			System.out.println("Bank deleted");
		}
		else {
			System.out.println("Not Found");
			BankNotFoundException exc=new BankNotFoundException("Not found "+bank.getBankId());
			throw exc;
		}
	}
	
	@PostMapping
	@RequestMapping(path="/updateBank")
	public void updateBank(@RequestBody Bank bank) throws BankNotFoundException{
		System.out.println("modify Bank Name :"+bank.getBankName());
		boolean found=false;
		bankService.updateBankDetailsService(bank);
		found=true;
		if(found) {
			System.out.println("Record modified");
		}
		else {
			System.out.println("Not Found");
			BankNotFoundException exception=new BankNotFoundException("Not Found"+bank.getBankId());
			throw exception;
		}
	}
	
	
	*/
	
	
}
