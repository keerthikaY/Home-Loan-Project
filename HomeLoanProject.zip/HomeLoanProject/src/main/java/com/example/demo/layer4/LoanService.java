package com.example.demo.layer4;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.demo.layer2.model.Loan;

@Service
public interface LoanService {
	
	public Loan getLoanDetailsByIdService(Integer loanId );
	public void addLoanDetailsService(Loan loan);
	public List<Loan> getAllLoanDetailsService();
	public void deleteLoanDetailsService(Integer loanId);
	public void updateLoanDetailsService(Loan findObj);
	public Loan getLoanByAppId(Integer appId);
}