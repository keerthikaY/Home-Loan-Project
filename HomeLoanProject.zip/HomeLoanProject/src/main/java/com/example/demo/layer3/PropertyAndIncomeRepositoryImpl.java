package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.example.demo.layer2.model.Propertyandincome;

@Repository
public class PropertyAndIncomeRepositoryImpl extends BaseRepository implements PropertyAndIncomeRepository {

	@PersistenceContext
	private EntityManager enitityManager;
    
	@Transactional
	public void addPropertyAndIncomeDetails(Propertyandincome propertyAndIncome) {
		super.persist(propertyAndIncome);
	}
     
	@Transactional
	public Propertyandincome getPropertyAndIncomeListById(Integer property_id) {
		return super.find(Propertyandincome.class,property_id);
	}
    
	@Transactional
	public void deletePropertyAndIncome(Integer property_id) {
		super.remove(Propertyandincome.class,property_id);
		
	}
    
	@Transactional
	public void updatePropertyAndIncome(Propertyandincome propertyAndIncome) {
		super.merge(propertyAndIncome);
		
	}

	@Transactional
	public List<Propertyandincome> getAllPropertyAndIncome() {
		return super.findAll("PropertyAndIncome");
	}

	

}