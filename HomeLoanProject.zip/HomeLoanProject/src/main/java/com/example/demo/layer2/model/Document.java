package com.example.demo.layer2.model;

import java.io.Serializable;
import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonIgnore;


/**
 * The persistent class for the DOCUMENT database table.
 * 
 */
@Entity
@NamedQuery(name="Document.findAll", query="SELECT d FROM Document d")
public class Document implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="DOC_ID")
	private Integer docId;
	
	@Column(name="AGREEMENT_TO_SALE")
	private String agreementToSale;
	
	@Column(name="LOA")
	private String loa;
	
	@Column(name="NOC_FROM_BUILDER")
	private String nocFromBuilder;
	
	@Column(name="PAN_CARD")
	private String panCard;
	
	@Column(name="SALARY_SLIP")
	private String salarySlip;
	
	@Column(name="VOTER_ID")
	private String voterId;
	
	@OneToOne(mappedBy="document",cascade=CascadeType.ALL)
	private Application application;

	public Document() {
	}


	
	
	public Integer getDocId() {
		return this.docId;
	}

	public void setDocId(Integer docId) {
		this.docId = docId;
	}


	
	public String getAgreementToSale() {
		return this.agreementToSale;
	}

	public void setAgreementToSale(String agreementToSale) {
		this.agreementToSale = agreementToSale;
	}


	public String getLoa() {
		return this.loa;
	}

	public void setLoa(String loa) {
		this.loa = loa;
	}


	
	public String getNocFromBuilder() {
		return this.nocFromBuilder;
	}

	public void setNocFromBuilder(String nocFromBuilder) {
		this.nocFromBuilder = nocFromBuilder;
	}


	
	public String getPanCard() {
		return this.panCard;
	}

	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}


	public String getSalarySlip() {
		return this.salarySlip;
	}

	public void setSalarySlip(String salarySlip) {
		this.salarySlip = salarySlip;
	}


	public String getVoterId() {
		return this.voterId;
	}

	public void setVoterId(String voterId) {
		this.voterId = voterId;
	}


	//bi-directional one-to-one association to Application
	@JsonIgnore
	public Application getApplication() {
		return this.application;
	}

	public void setApplication(Application application) {
		this.application = application;
	}

}