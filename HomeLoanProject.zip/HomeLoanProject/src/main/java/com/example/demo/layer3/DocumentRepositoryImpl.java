package com.example.demo.layer3;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Document;

@Repository
public class DocumentRepositoryImpl extends BaseRepository implements DocumentRepository {

	@PersistenceContext
	private EntityManager entityManager;

	@Transactional
	public void addUserDoc(Document docId) {
		super.persist(docId);
	}

	@Transactional
	public Document getDocument(Integer docId) {
		System.out.println(docId);
		return super.find(Document.class, docId);
	}

	@Transactional
	public List<Document> getAllUserDocuments() {
		// TODO Auto-generated method stub
		return super.findAll("Document");
	}

	@Transactional
	public void deleteUserDoc(Integer docId) {
		// TODO Auto-generated method stub
		super.remove(Document.class,docId);
	}

	@Transactional
	public void updateDocument(Document docId) {
		// TODO Auto-generated method stub
		super.merge(docId);
	}

	@Override
	public Integer getDocIdByPanCard(String pan) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
