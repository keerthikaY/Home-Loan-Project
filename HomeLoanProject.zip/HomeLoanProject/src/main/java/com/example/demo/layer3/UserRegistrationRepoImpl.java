package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;


import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.HomeUser;
@Repository
public class UserRegistrationRepoImpl extends BaseRepository implements UserRegistrationRepo{
	@PersistenceContext
	private EntityManager entitymanager;

	@Transactional
	public HomeUser getHomeUser(Integer userId)  {
		System.out.println(userId);
		return super.find(HomeUser.class, userId);
	}

	@Transactional
	public void addHomeUser(HomeUser homeuser)  {
		// TODO Auto-generated method stub
		System.out.println("adding");
		super.persist(homeuser);
		
		
	}
	@Transactional
	public void updateHomeUser(HomeUser homeuser) {
		super.merge(homeuser);
	}
	@Transactional
	public void deleteHomeUser(Integer userId) {
		System.out.println("removing");
		super.remove(HomeUser.class, userId);
	}
	@Transactional
	public List<HomeUser> getAllHomeUser() {
		return super.findAll("HomeUser");
	}
    
	@Transactional
	public HomeUser findUserByEmailAndPass(String email,String pass) {
		return super.findUserByEmail(email, pass);
	}

	@Transactional
	public HomeUser findUserByEmail(String email) {
		try {
			  Query query=entityManager.createQuery("select u from HomeUser u where u.email='"+email+"'");
			return (HomeUser) query.getSingleResult();
			}
			finally {
			entityManager.close();
			}
	}

	
}