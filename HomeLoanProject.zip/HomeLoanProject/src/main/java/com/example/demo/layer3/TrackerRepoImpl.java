package com.example.demo.layer3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.Tracker;

@Repository
public class TrackerRepoImpl extends BaseRepository implements TrackerRepo
{
   @PersistenceContext
   private EntityManager entity;
	
	@Transactional
	public Tracker getTrackerDetailsById(Integer trackerId) {
		return super.find(Tracker.class, trackerId);
	}

	@Transactional
	public void addTrackerDetails(Tracker tracker) {
		super.merge(tracker);
	}

	@Transactional
	public List<Tracker> getAllTrackerDetails() {
		List<Tracker> tracker=super.findAll("Tracker");
		return tracker;
	}

		
	}


