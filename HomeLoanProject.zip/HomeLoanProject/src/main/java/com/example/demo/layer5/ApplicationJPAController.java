package com.example.demo.layer5;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.layer2.model.Application;
import com.example.demo.layer2.model.Bank;
import com.example.demo.layer2.model.Document;
import com.example.demo.layer2.model.HomeUser;
import com.example.demo.layer2.model.Loan;
import com.example.demo.layer2.model.LoanStatusDto;
import com.example.demo.layer2.model.Propertyandincome;
import com.example.demo.layer2.model.Tracker;
import com.example.demo.layer3.BankRepository;
import com.example.demo.layer3.DocumentRepository;
import com.example.demo.layer3.LoanRepository;
import com.example.demo.layer3.PropertyAndIncomeRepository;
import com.example.demo.layer3.TrackerRepo;
import com.example.demo.layer4.ApplicationService;
import com.example.demo.layer4.BankService;
import com.example.demo.layer4.DocumentService;
import com.example.demo.layer4.HomeUserService;
import com.example.demo.layer4.LoanService;
import com.example.demo.layer4.PropertyandIncomeService;
import com.example.demo.layer4.TrackerService;

@CrossOrigin(origins = "*", value = "*")
@RestController
public class ApplicationJPAController {
	@Autowired
	ApplicationService appService;
	
	@Autowired
	BankService bankService;
	
	@Autowired
	DocumentService documentService;
	
	@Autowired
	PropertyandIncomeService propertyAndIncomeService;
	
	@Autowired
	LoanService loanService;
	
	@Autowired
	TrackerService trackerService;
	
	@Autowired
	HomeUserService userService;
	
	@GetMapping
	@RequestMapping(path="/getJPAallApps") //localhost:8080/getDepts
	public List<Application> getAllAppDetailss() {
		System.out.println("getAllDocuments");
		return appService.findAllApplicationService();
	}
	
	@GetMapping
	@RequestMapping(path="/getJPAApp/{appId}") // localhost:8080/getDept/10
	public Application getApplication(@PathVariable("appId") int appIdToFind) throws AppNotFoundException 
	{
		System.out.println("getApplication : "+appIdToFind);
		Application foundapp = null;
		foundapp = appService.getApplicationService(appIdToFind);
	
		if(foundapp == null) {
			AppNotFoundException a = new AppNotFoundException("Document  Not Found "+appIdToFind);
		}
		
		return foundapp;
	}
	@PostMapping
	@RequestMapping(path="/updateApplication")
	public void updateDocument(@RequestBody Application app) throws AppNotFoundException{
		System.out.println("modify pan card path :"+app.getDateOfApp());
		boolean found=false;
		appService.updateApplicationService(app);
		found=true;
		if(found) {
			System.out.println("Record modified");
		}
		else {
			System.out.println("Not Found");
			AppNotFoundException exception=new AppNotFoundException("Not Found"+app.getDateOfApp());
			throw exception;
		}
	}
	
	@PostMapping
	@RequestMapping(path="/deleteJPAApp") // localhost:8080/deleteDept/10
	public void deleteDocument(@RequestBody Application app) throws AppNotFoundException 
	{
		System.out.println("deleteDocument : "+app.getAppId()); 
		boolean found=false;
		
		appService.deleteApplicationService(app.getAppId());
		found=true;
			
		
		if(found) {
			System.out.println("App Deleted");
		}
		else {
			System.out.println("Not found");
			AppNotFoundException appNotFound = new AppNotFoundException("Department Number Not Found "+app.getAppId());
			throw appNotFound;
		}
		
	}
	/*@PostMapping
	@RequestMapping(path="/addUserId/")
	public void addApplication(@RequestParam("email") String email) {
		Application appobj=new Application();
		
		Integer id=userService.
		System.out.println(id);
		HomeUser user=userService.findHomeById(id);
		appobj.setHomeUser(user);
		appService.addApplicationService(appobj);
	}*/
	
	@PostMapping
	@RequestMapping(path="/addApplication/{email}")
	public void addApplication(@RequestBody Application AppToInsert,@PathVariable("email")String email) {
		Application appobj=new Application();
		
		  SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		  Date date = new Date();
		  appobj.setDateOfApp(date);
		
		//Integer id=userService.getUserByEmailService(email);
		HomeUser user=userService.findUserByEmailService(email);
		appobj.setHomeUser(user);
		//appService.addApplicationService(appobj);
		
		Bank bankObj=new Bank();
		Bank b=AppToInsert.getBank();
		bankObj.setAccNo(b.getAccNo());
		bankObj.setBankName(b.getBankName());
		bankObj.setIfscCode(b.getIfscCode());
		appobj.setBank(bankObj);
		
		Document docObj=new Document();
		Document d=AppToInsert.getDocument();
		docObj.setAgreementToSale(d.getAgreementToSale());
		docObj.setLoa(d.getLoa());
		docObj.setNocFromBuilder(d.getNocFromBuilder());
		docObj.setPanCard(d.getPanCard());
		docObj.setSalarySlip(d.getSalarySlip());
		docObj.setVoterId(d.getVoterId());
		appobj.setDocument(docObj);
		
		Propertyandincome propObj=new Propertyandincome();
		Propertyandincome p=AppToInsert.getPropertyandincome();
		propObj.setEmployerName(p.getEmployerName());
		propObj.setEstimatedAmt(p.getEstimatedAmt());
		propObj.setIncome(p.getIncome());
		propObj.setOrgType(p.getOrgType());
		propObj.setPropertyLoc(p.getPropertyLoc());
		propObj.setPropertyName(p.getPropertyName());
		propObj.setRetAge(p.getRetAge());
		propObj.setTypeOfEmp(p.getTypeOfEmp());
		appobj.setPropertyandincome(propObj);
		
		Loan loanobj= new Loan();
		Loan l=AppToInsert.getLoan();
		loanobj.setEmi(l.getEmi());
		loanobj.setLoanAmount(l.getLoanAmount());
		loanobj.setRoi(l.getRoi());
		loanobj.setTenure(l.getTenure());
		appobj.setLoan(loanobj);
		
		Tracker trackObj=new Tracker();
		//Tracker t=AppToInsert.getTracker();
		trackObj.setAprrovedDate(date);
		trackObj.setStatus("Sent for Verification");
		appobj.setTracker(trackObj);
		appService.addApplicationService(appobj);
	}
	
	@PostMapping
	@RequestMapping(path="/getTracker/{appId}")
	public Tracker addApplication(@PathVariable("appId") Integer appId) {
		return appService.gettrackerByAppId(appId);
		
	}
	@PostMapping
	@RequestMapping(path="/setStatusApproved/{appId}")
	public void addStatusApproved(@PathVariable("appId") Integer appId) {
		 Application app=appService.getApplicationService(appId);
		 Tracker t=app.getTracker();
		 t.setStatus("Approved");
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		  Date date = new Date();
		 t.setAprrovedDate(date);
		 appService.updateApplicationService(app);
	}
	@PostMapping
	@RequestMapping(path="/setStatusRejected/{appId}")
	public void addStatusRejected(@PathVariable("appId") Integer appId) {
		 Application app=appService.getApplicationService(appId);
		 Tracker t=app.getTracker();
		 t.setStatus("Rejected");
		 SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		  Date date = new Date();
		 t.setAprrovedDate(date);
		 appService.updateApplicationService(app);
	}
	@PostMapping
	@RequestMapping(path="/findStatusById/{appId}")
	public LoanStatusDto getStatusById(@PathVariable("appId") Integer appId) {
		Application app=appService.getApplicationService(appId);
		 Tracker t=app.getTracker();
		 String status=t.getStatus();
		 Date appDate=t.getAprrovedDate();
		 LoanStatusDto loanStatus=new LoanStatusDto();
		 loanStatus.setStatus(status);
		 loanStatus.setAprrovedDate(appDate);
		 return loanStatus;
	}


}
