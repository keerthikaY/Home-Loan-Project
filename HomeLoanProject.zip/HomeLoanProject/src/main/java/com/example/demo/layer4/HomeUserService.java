package com.example.demo.layer4;

import java.util.List;
import org.springframework.stereotype.*;
import com.example.demo.layer2.model.HomeUser;

@Service
public interface HomeUserService {
	List<HomeUser> findAllHomeUsers();
	
	public HomeUser findHomeById(Integer userId);
	public void DeleteUserService(Integer userId);
	public void UpdateUserService(HomeUser homeUser);
	public void addHomeDetailsService(HomeUser homeUser);
	public HomeUser getUserByEmailAndPassService(String email,String pass);
	public HomeUser findUserByEmailService(String email);
}